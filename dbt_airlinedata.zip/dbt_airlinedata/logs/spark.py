print "Hello Spark World"
from pyspark.sql import SparkSession
from pyspark.sql.functions import split, col, regexp_replace
import sys
spark = SparkSession \
    .builder \
    .appName("Pyspark AIRLINES ETL") \
    .getOrCreate()

#The path of our file in S3
input_path ='s3a://goes-se-sandbox01/airlines-csv/'

#This is to deal with tables existing before running this code. Not needed if you're starting fresh.
spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

tableName = 'flights'
#Bring data into our Spark job from S3 bucket
flights_df=spark.read.option("header","true").option("inferSchema","true").csv(input_path+tableName+'/'+tableName+".csv")

#Check the schema so we know what we're dealing with
print("printing schema")
flights_df.printSchema()


