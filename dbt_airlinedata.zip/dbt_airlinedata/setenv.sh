export DBT_HIVE_SCHEMA=dbt_airlinedata
export DBT_HIVE_USER=frothkoetter
export DBT_HIVE_PASSWORD='$SAX201linga$'
export DBT_HIVE_HOST="hs2-cdw-aw-se-hive.dw-se-sandboxx-aws.a465-9q4k.cloudera.site"
export DBT_HIVE_PORT=443
export DBT_HIVE_THREADS=1
export DBT_HIVE_HTTP_PATH="jdbc:hive2://hs2-cdw-aw-se-hive.dw-se-sandboxx-aws.a465-9q4k.cloudera.site/default;transportMode=http;httpPath=cliservice;socketTimeout=60;ssl=true;auth=browser;"